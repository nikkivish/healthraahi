import { useState } from 'react';
import { useLanguage } from '../i18n/LanguageContext';

function LanguageSwitcher() {
  const { language, setLanguage, t, availableLanguages } = useLanguage();
  const [langOpen, setLangOpen] = useState(false);

  const currentLangName =
    availableLanguages.find((l) => l.code === language)?.name || 'English';

  return (
    <div className="language-toggle-wrap">
      <button
        className="language-toggle"
        type="button"
        aria-label={t('nav.selectLanguage')}
        onClick={() => setLangOpen(!langOpen)}
      >
        <span className="lang-icon">🌐</span>
        <span>{currentLangName}</span>
        <span className="caret">▾</span>
      </button>
      {langOpen && (
        <div className="lang-dropdown">
          {availableLanguages.map((lang) => (
            <button
              key={lang.code}
              className={`lang-option ${language === lang.code ? 'active' : ''}`}
              onClick={() => {
                setLanguage(lang.code);
                setLangOpen(false);
              }}
            >
              {lang.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default LanguageSwitcher;
