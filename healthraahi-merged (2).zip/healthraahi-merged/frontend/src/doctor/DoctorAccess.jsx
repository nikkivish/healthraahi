import { useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { useAuth } from '../auth/AuthContext';
import { API_BASE } from '../api';

function DoctorAccess() {
  const { token } = useAuth();

  const [healthId, setHealthId] = useState('');
  const [worker, setWorker] = useState(null);
  const [searchError, setSearchError] = useState('');

  const [verificationMethod, setVerificationMethod] = useState('');

  // OTP
  const [otp, setOtp] = useState('');
  const [demoOtp, setDemoOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  // PIN
  const [pin, setPin] = useState('');

  const [verified, setVerified] = useState(false);
  const [verificationError, setVerificationError] = useState('');

  // QR Scanner
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerError, setScannerError] = useState('');
  const scannerRef = useRef(null);

  const [showRecords, setShowRecords] = useState(false);

  // ------------------------------------------------------------------
  // DEMO CLINICAL RECORDS
  // ------------------------------------------------------------------

  const demoRecords = [
    {
      type: 'Consultation',
      title: 'General Health Checkup',
      doctor: 'Dr. Ananya Sharma',
      date: '18 August 2026',
      diagnosis: 'Hypertension',
      notes: 'Regular monitoring recommended.',
    },
    {
      type: 'Prescription',
      title: 'Medication Record',
      doctor: 'Dr. Ananya Sharma',
      date: '18 August 2026',
      diagnosis: 'Blood pressure management',
      notes: 'Medication prescribed for blood pressure control.',
    },
    {
      type: 'Lab Report',
      title: 'Blood Test',
      doctor: 'City Health Centre',
      date: '15 August 2026',
      diagnosis: 'Routine blood examination',
      notes: 'Results within acceptable range.',
    },
  ];

  // ------------------------------------------------------------------
  // SEARCH WORKER
  // ------------------------------------------------------------------

  const calculateAge = (dateOfBirth) => {
  if (!dateOfBirth) return '—';

  const birthDate = new Date(dateOfBirth);

  if (Number.isNaN(birthDate.getTime())) {
    return '—';
  }

  const today = new Date();

  let age =
    today.getFullYear() -
    birthDate.getFullYear();

  const monthDifference =
    today.getMonth() -
    birthDate.getMonth();

  if (
    monthDifference < 0 ||
    (monthDifference === 0 &&
      today.getDate() < birthDate.getDate())
  ) {
    age--;
  }

  return age;
};

const normalizeWorker = (
  result,
  fallbackHealthId
) => {
  const raw =
    result?.data?.profile ||
    result?.data?.worker ||
    result?.data?.workerProfile ||
    result?.profile ||
    result?.worker ||
    result?.workerProfile ||
    result?.data;

  if (!raw || typeof raw !== 'object') {
    return null;
  }

  return {
    ...raw,

    healthId:
      raw.healthId ||
      raw.healthID ||
      raw.health_id ||
      fallbackHealthId,

    name:
      raw.name ||
      raw.fullName ||
      'Worker',

    age:
      raw.age ??
      calculateAge(raw.dateOfBirth),

    dateOfBirth:
      raw.dateOfBirth || null,

    gender:
      raw.gender || '—',

    bloodGroup:
      raw.bloodGroup || '—',

    weight:
      raw.weight ??
      '—',

    phone:
      raw.phone ||
      raw.mobile ||
      raw.mobileNumber ||
      '—',

    consent:
      raw.consent ||
      'Requires Verification',
  };
};

  const lookupWorkerByHealthId = async (id) => {
    const normalizedId = String(id || '').trim().toUpperCase();

    if (!normalizedId) {
      throw new Error('Please enter a Health ID.');
    }

    if (!token) {
      throw new Error('Your doctor session has expired. Please login again.');
    }

    const response = await fetch(
      `${API_BASE}/workers/lookup/${encodeURIComponent(normalizedId)}`,
      {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(
        result?.message ||
          result?.error ||
          'Worker not found. Please check the Health ID.'
      );
    }

    const foundWorker = normalizeWorker(result, normalizedId);

    if (!foundWorker) {
      throw new Error('Worker profile was not returned by the server.');
    }

    return foundWorker;
  };

  // ------------------------------------------------------------------
  // SEARCH WORKER
  // ------------------------------------------------------------------

  const handleSearch = async (e) => {
    e.preventDefault();

    setSearchError('');
    setWorker(null);
    setVerified(false);
    setShowRecords(false);
    setVerificationMethod('');
    setVerificationError('');
    setOtp('');
    setDemoOtp('');
    setOtpSent(false);
    setPin('');

    const normalizedId = healthId.trim().toUpperCase();

    if (!normalizedId) {
      setSearchError('Please enter a Health ID.');
      return;
    }

    try {
      const foundWorker = await lookupWorkerByHealthId(normalizedId);

      setHealthId(normalizedId);
      setWorker(foundWorker);
    } catch (error) {
      console.error('Worker lookup error:', error);
      setSearchError(
        error?.message || 'Worker not found. Please check the Health ID.'
      );
    }
  };

  // ------------------------------------------------------------------
  // QR SCANNER
  // ------------------------------------------------------------------

  const stopQrScanner = async () => {
    try {
      if (scannerRef.current) {
        const state = scannerRef.current.getState?.();

        if (state === 2) {
          await scannerRef.current.stop();
        }

        await scannerRef.current.clear();
        scannerRef.current = null;
      }
    } catch (error) {
      console.warn('QR scanner cleanup:', error);
    } finally {
      setScannerOpen(false);
    }
  };

  const extractHealthId = (decodedText) => {
    const value = String(decodedText || '').trim();

    // Try JSON
    try {
      const parsed = JSON.parse(value);

      return (
        parsed.healthId ||
        parsed.healthID ||
        parsed.health_id ||
        parsed.id ||
        ''
      )
        .toString()
        .trim();
    } catch {
      // Not JSON, continue
    }

    // Try URL
    try {
      const url = new URL(value);

      const fromQuery =
        url.searchParams.get('healthId') ||
        url.searchParams.get('healthID') ||
        url.searchParams.get('health_id');

      if (fromQuery) {
        return fromQuery.trim();
      }

      // WorkerHealthId currently generates URLs like:
      // /worker/lookup/WH-20260818-A76ENP
      const pathParts = url.pathname
        .split('/')
        .map((part) => decodeURIComponent(part))
        .filter(Boolean);

      const lookupIndex = pathParts.findIndex(
        (part) => part.toLowerCase() === 'lookup'
      );

      if (lookupIndex !== -1 && pathParts[lookupIndex + 1]) {
        return pathParts[lookupIndex + 1].trim();
      }

      // Also support a QR containing only the final path segment.
      if (pathParts.length > 0) {
        const lastPart = pathParts[pathParts.length - 1].trim();

        if (/^(WH|HRH)-[A-Z0-9-]+$/i.test(lastPart)) {
          return lastPart;
        }
      }
    } catch {
      // Not a URL
    }

    // Plain text QR
    return value;
  };

  const startQrScanner = () => {
    setScannerError('');
    setScannerOpen(true);

    setTimeout(async () => {
      try {
        const scanner = new Html5Qrcode('qr-reader');

        scannerRef.current = scanner;

        await scanner.start(
          { facingMode: 'environment' },
          {
            fps: 10,
            qrbox: {
              width: 250,
              height: 250,
            },
          },
          async (decodedText) => {
            const scannedHealthId = extractHealthId(decodedText);

            if (!scannedHealthId) {
              setScannerError(
                'QR detected, but no Health ID was found.'
              );
              return;
            }

            await stopQrScanner();

            const normalizedId = scannedHealthId.trim().toUpperCase();
            setHealthId(normalizedId);

            try {
              // Load the real worker profile instead of creating a demo worker.
              const foundWorker = await lookupWorkerByHealthId(normalizedId);

              setWorker(foundWorker);
              setVerificationMethod('');
              setVerificationError('');
              setVerified(false);
              setShowRecords(false);
            } catch (error) {
              console.error('Scanned worker lookup error:', error);
              setWorker(null);
              setScannerError(
                error?.message ||
                  'QR was scanned, but the worker profile could not be found.'
              );
            }
          },
          () => {
            // Normal frame-by-frame scan misses are ignored.
          }
        );
      } catch (error) {
        console.error('QR scanner error:', error);

        setScannerError(
          'Unable to start the camera. Please allow camera access and try again.'
        );

        await stopQrScanner();
      }
    }, 100);
  };

  // ------------------------------------------------------------------
  // DYNAMIC DEMO OTP
  // ------------------------------------------------------------------

  const sendDemoOtp = () => {
    const generatedOtp = Math.floor(
      100000 + Math.random() * 900000
    ).toString();

    setDemoOtp(generatedOtp);
    setOtp('');
    setOtpSent(true);
    setVerificationError('');
  };

  // ------------------------------------------------------------------
  // VERIFY OTP / PIN
  // ------------------------------------------------------------------

  const handleVerification = async () => {
    setVerificationError('');

    // ---------------- OTP ----------------

    if (verificationMethod === 'otp') {
      if (!otpSent) {
        setVerificationError(
          'Please request an OTP first.'
        );
        return;
      }

      if (otp === demoOtp) {
        setVerified(true);

        setWorker({
          ...worker,
          consent: 'Granted',
        });
      } else {
        setVerificationError(
          'Invalid OTP. Please check the OTP and try again.'
        );
      }

      return;
    }

    // ---------------- QR + PIN ----------------

    if (verificationMethod === 'qr') {
      if (!healthId.trim()) {
        setVerificationError('Please scan the worker Health ID QR first.');
        return;
      }

      if (!pin || pin.length !== 4) {
        setVerificationError('Please enter the 4-digit Health PIN.');
        return;
      }

      if (!token) {
        setVerificationError('Your doctor session has expired. Please login again.');
        return;
      }

      try {
        const response = await fetch('/api/workers/verify-qr-pin', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            healthId: healthId.trim().toUpperCase(),
            pin: pin.trim(),
          }),
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
          throw new Error(
            result?.message ||
              result?.error ||
              'Worker verification failed.'
          );
        }

        const verifiedWorker = result?.data?.worker;

        setVerified(true);

        setWorker({
          ...worker,
          ...(verifiedWorker || {}),
          healthId:
            result?.data?.healthId ||
            verifiedWorker?.healthId ||
            healthId.trim().toUpperCase(),
          consent: 'Granted',
        });
      } catch (error) {
        console.error('QR + PIN verification error:', error);

        setVerified(false);
        setVerificationError(
          error?.message || 'Unable to verify worker. Please try again.'
        );
      }
    }
  };

  // ------------------------------------------------------------------
  // RESET
  // ------------------------------------------------------------------

  const resetFlow = async () => {
    await stopQrScanner();

    setHealthId('');
    setWorker(null);
    setSearchError('');
    setVerificationMethod('');

    setOtp('');
    setDemoOtp('');
    setOtpSent(false);

    setPin('');

    setVerified(false);
    setVerificationError('');
    setShowRecords(false);
  };

  // ------------------------------------------------------------------
  // UI
  // ------------------------------------------------------------------

  return (
    <div
      style={{
        padding: '32px',
        minHeight: '100%',
        background: '#f5f8f6',
      }}
    >
      {/* HEADER */}

      <div style={{ marginBottom: '28px' }}>
        <h1
          style={{
            margin: 0,
            color: '#073b4c',
            fontSize: '30px',
          }}
        >
          Doctor Access
        </h1>

        <p
          style={{
            marginTop: '8px',
            color: '#667085',
          }}
        >
          Securely access a worker's health records using their Health ID.
        </p>
      </div>

      {/* ================================================================
          SEARCH WORKER
      ================================================================= */}

      {!worker && (
        <div
          style={{
            background: '#ffffff',
            padding: '28px',
            borderRadius: '14px',
            boxShadow: '0 4px 18px rgba(0,0,0,0.05)',
            maxWidth: '800px',
          }}
        >
          <h2
            style={{
              marginTop: 0,
              color: '#073b4c',
            }}
          >
            Search Worker
          </h2>

          <p style={{ color: '#667085' }}>
            Enter the worker's Health ID to request access to their records.
          </p>

          <form onSubmit={handleSearch}>
            <label
              style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: '#344054',
              }}
            >
              Health ID
            </label>

            <div
              style={{
                display: 'flex',
                gap: '12px',
                flexWrap: 'wrap',
              }}
            >
              <input
                type="text"
                value={healthId}
                onChange={(e) => setHealthId(e.target.value)}
                placeholder="e.g. HRH-1001"
                style={{
                  flex: 1,
                  minWidth: '250px',
                  padding: '13px 15px',
                  border: '1px solid #d0d5dd',
                  borderRadius: '9px',
                  fontSize: '16px',
                  outline: 'none',
                }}
              />

              <button
                type="submit"
                style={primaryButton}
              >
                Search
              </button>
            </div>
          </form>

          {searchError && (
            <div
              style={{
                marginTop: '18px',
                padding: '14px',
                borderRadius: '9px',
                background: '#fff4f2',
                border: '1px solid #ffb4aa',
                color: '#b42318',
              }}
            >
              {searchError}
            </div>
          )}


        </div>
      )}

      {/* ================================================================
          WORKER FOUND
      ================================================================= */}

      {worker && !verified && (
        <>
          {/* WORKER CARD */}

          <div
            style={{
              background: '#ffffff',
              padding: '28px',
              borderRadius: '14px',
              boxShadow: '0 4px 18px rgba(0,0,0,0.05)',
              marginBottom: '20px',
            }}
          >
            <span
              style={{
                display: 'inline-block',
                background: '#e5f6f3',
                color: '#087f8c',
                padding: '6px 12px',
                borderRadius: '20px',
                fontSize: '13px',
                fontWeight: '600',
                marginBottom: '10px',
              }}
            >
              ✓ Worker Found
            </span>

            <h2
              style={{
                margin: '5px 0',
                color: '#073b4c',
              }}
            >
              {worker.name}
            </h2>

            <p
              style={{
                margin: '5px 0',
                color: '#667085',
              }}
            >
              Health ID: <strong>{worker.healthId}</strong>
            </p>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns:
                  'repeat(auto-fit, minmax(180px, 1fr))',
                gap: '15px',
                marginTop: '22px',
              }}
            >
              <InfoBox
                label="Age"
                value={`${worker.age} years`}
              />

              <InfoBox
                label="Gender"
                value={worker.gender}
              />

              <InfoBox
                label="Blood Group"
                value={worker.bloodGroup}
              />

              <InfoBox
                label="Consent"
                value="Requires Verification"
              />
            </div>
          </div>

          {/* ============================================================
              VERIFICATION
          ============================================================= */}

          <div
            style={{
              background: '#ffffff',
              padding: '28px',
              borderRadius: '14px',
              boxShadow: '0 4px 18px rgba(0,0,0,0.05)',
            }}
          >
            <h2
              style={{
                marginTop: 0,
                color: '#073b4c',
              }}
            >
              Verify Worker Identity
            </h2>

            <p style={{ color: '#667085' }}>
              Choose a secure verification method before accessing
              clinical records.
            </p>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns:
                  'repeat(auto-fit, minmax(260px, 1fr))',
                gap: '18px',
                marginTop: '20px',
              }}
            >
              {/* OTP BUTTON */}

              <button
                type="button"
                onClick={() => {
                  setVerificationMethod('otp');
                  setVerificationError('');
                }}
                style={{
                  padding: '24px',
                  textAlign: 'left',
                  border:
                    verificationMethod === 'otp'
                      ? '2px solid #087f8c'
                      : '1px solid #d0d5dd',
                  borderRadius: '12px',
                  background: '#ffffff',
                  cursor: 'pointer',
                }}
              >
                <div style={{ fontSize: '30px' }}>
                  📱
                </div>

                <h3 style={{ color: '#073b4c' }}>
                  Mobile OTP
                </h3>

                <p
                  style={{
                    color: '#667085',
                    marginBottom: 0,
                  }}
                >
                  Verify the worker using a one-time password.
                </p>
              </button>

              {/* QR BUTTON */}

              <button
                type="button"
                onClick={() => {
                  setVerificationMethod('qr');
                  setVerificationError('');
                }}
                style={{
                  padding: '24px',
                  textAlign: 'left',
                  border:
                    verificationMethod === 'qr'
                      ? '2px solid #087f8c'
                      : '1px solid #d0d5dd',
                  borderRadius: '12px',
                  background: '#ffffff',
                  cursor: 'pointer',
                }}
              >
                <div style={{ fontSize: '30px' }}>
                  📷
                </div>

                <h3 style={{ color: '#073b4c' }}>
                  QR + PIN
                </h3>

                <p
                  style={{
                    color: '#667085',
                    marginBottom: 0,
                  }}
                >
                  Verify using the worker's Health ID QR and PIN.
                </p>
              </button>
            </div>

            {/* ==========================================================
                OTP FORM
            =========================================================== */}

            {verificationMethod === 'otp' && (
              <div
                style={{
                  marginTop: '25px',
                  padding: '20px',
                  background: '#f8faf9',
                  borderRadius: '10px',
                }}
              >
                {!otpSent ? (
                  <>
                    <div
                      style={{
                        background: '#eef8f7',
                        padding: '18px',
                        borderRadius: '10px',
                        marginBottom: '20px',
                      }}
                    >
                      <div style={{ fontSize: '28px' }}>
                        📱
                      </div>

                      <h3
                        style={{
                          color: '#073b4c',
                          margin: '8px 0',
                        }}
                      >
                        Verify Mobile Number
                      </h3>

                      <p
                        style={{
                          color: '#667085',
                          marginBottom: 0,
                        }}
                      >
                        A one-time password will be generated for
                        the worker's registered mobile number.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={sendDemoOtp}
                      style={primaryButton}
                    >
                      📩 Send OTP
                    </button>
                  </>
                ) : (
                  <>
                    {/* OTP SENT */}

                    <div
                      style={{
                        background: '#ecfdf3',
                        border: '1px solid #abefc6',
                        padding: '16px',
                        borderRadius: '10px',
                        marginBottom: '20px',
                      }}
                    >
                      <strong style={{ color: '#067647' }}>
                        ✓ OTP generated successfully
                      </strong>

                      <p
                        style={{
                          margin: '8px 0 0',
                          color: '#475467',
                        }}
                      >
                        OTP sent to registered mobile number ending
                        in <strong>{worker.phone}</strong>
                      </p>
                    </div>

                    {/* DEMO OTP */}

                    <div
                      style={{
                        background: '#fff8e7',
                        border: '1px solid #f5d98b',
                        padding: '16px',
                        borderRadius: '10px',
                        marginBottom: '20px',
                      }}
                    >
                      <strong style={{ color: '#7a5a00' }}>
                        🧪 Prototype Demo Mode
                      </strong>

                      <p
                        style={{
                          margin: '8px 0',
                          color: '#667085',
                          fontSize: '14px',
                        }}
                      >
                        In this prototype, the generated OTP is
                        displayed here. Production SMS delivery will
                        be connected later.
                      </p>

                      <div
                        style={{
                          fontSize: '28px',
                          fontWeight: '700',
                          letterSpacing: '8px',
                          color: '#073b4c',
                        }}
                      >
                        {demoOtp}
                      </div>
                    </div>

                    {/* ENTER OTP */}

                    <label
                      style={{
                        display: 'block',
                        fontWeight: '600',
                        marginBottom: '8px',
                        color: '#344054',
                      }}
                    >
                      Enter OTP
                    </label>

                    <input
                      value={otp}
                      onChange={(e) =>
                        setOtp(
                          e.target.value
                            .replace(/\D/g, '')
                            .slice(0, 6)
                        )
                      }
                      placeholder="Enter 6-digit OTP"
                      inputMode="numeric"
                      maxLength={6}
                      style={{
                        width: '100%',
                        maxWidth: '350px',
                        padding: '12px',
                        border: '1px solid #d0d5dd',
                        borderRadius: '8px',
                        fontSize: '18px',
                        letterSpacing: '4px',
                        boxSizing: 'border-box',
                      }}
                    />

                    <div style={{ marginTop: '15px' }}>
                      <button
                        type="button"
                        onClick={handleVerification}
                        style={primaryButton}
                      >
                        ✓ Verify OTP
                      </button>

                      <button
                        type="button"
                        onClick={sendDemoOtp}
                        style={{
                          marginLeft: '10px',
                          padding: '12px 18px',
                          border: '1px solid #d0d5dd',
                          borderRadius: '8px',
                          background: '#ffffff',
                          color: '#344054',
                          cursor: 'pointer',
                          fontWeight: '600',
                        }}
                      >
                        Resend OTP
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* ==========================================================
                QR + PIN FORM
            =========================================================== */}

            {verificationMethod === 'qr' && (
              <div
                style={{
                  marginTop: '25px',
                  padding: '20px',
                  background: '#f8faf9',
                  borderRadius: '10px',
                }}
              >
                <h3
                  style={{
                    color: '#073b4c',
                    marginTop: 0,
                  }}
                >
                  Scan Worker QR
                </h3>

                <p style={{ color: '#667085' }}>
                  Open the worker's Health ID QR on their phone
                  and scan it with this camera.
                </p>

                {/* START SCANNER */}

                {!scannerOpen && (
                  <button
                    type="button"
                    onClick={startQrScanner}
                    style={primaryButton}
                  >
                    📷 Start QR Scanner
                  </button>
                )}

                {/* CAMERA */}

                {scannerOpen && (
                  <>
                    <div
                      id="qr-reader"
                      style={{
                        width: '100%',
                        maxWidth: '420px',
                        background: '#ffffff',
                        borderRadius: '10px',
                        overflow: 'hidden',
                        marginBottom: '15px',
                      }}
                    />

                    <button
                      type="button"
                      onClick={stopQrScanner}
                      style={{
                        ...primaryButton,
                        background: '#667085',
                      }}
                    >
                      Stop Camera
                    </button>
                  </>
                )}

                {/* SCANNER ERROR */}

                {scannerError && (
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#b42318',
                      background: '#fff4f2',
                      border: '1px solid #ffb4aa',
                      padding: '12px',
                      borderRadius: '8px',
                    }}
                  >
                    {scannerError}
                  </div>
                )}

                {/* AFTER QR SCAN */}

                {!scannerOpen && healthId && (
                  <>
                    <div
                      style={{
                        marginTop: '18px',
                        padding: '12px',
                        background: '#ecfdf3',
                        border: '1px solid #abefc6',
                        borderRadius: '8px',
                        color: '#067647',
                      }}
                    >
                      ✓ QR scanned successfully. Health ID detected:{' '}
                      <strong>{healthId}</strong>
                    </div>

                    <label
                      style={{
                        display: 'block',
                        fontWeight: '600',
                        marginTop: '18px',
                        marginBottom: '8px',
                        color: '#344054',
                      }}
                    >
                      Enter Health PIN
                    </label>

                    <input
                      value={pin}
                      onChange={(e) =>
                        setPin(
                          e.target.value
                            .replace(/\D/g, '')
                            .slice(0, 4)
                        )
                      }
                      placeholder="Enter 4-digit PIN"
                      inputMode="numeric"
                      maxLength={4}
                      style={{
                        width: '100%',
                        maxWidth: '350px',
                        padding: '12px',
                        border: '1px solid #d0d5dd',
                        borderRadius: '8px',
                        fontSize: '16px',
                        boxSizing: 'border-box',
                      }}
                    />

                    <p
                      style={{
                        fontSize: '13px',
                        color: '#667085',
                      }}
                    >
                      Prototype PIN: <strong>1234</strong>
                    </p>

                    <button
                      type="button"
                      onClick={handleVerification}
                      style={primaryButton}
                    >
                      Verify & Grant Access
                    </button>
                  </>
                )}
              </div>
            )}

            {/* VERIFICATION ERROR */}

            {verificationError && (
              <div
                style={{
                  marginTop: '15px',
                  color: '#b42318',
                  background: '#fff4f2',
                  border: '1px solid #ffb4aa',
                  padding: '12px',
                  borderRadius: '8px',
                }}
              >
                {verificationError}
              </div>
            )}

            {/* RESET */}

            <button
              type="button"
              onClick={resetFlow}
              style={{
                marginTop: '20px',
                background: 'transparent',
                border: 'none',
                color: '#667085',
                cursor: 'pointer',
              }}
            >
              ← Search another Health ID
            </button>
          </div>
        </>
      )}

      {/* ================================================================
          ACCESS GRANTED
      ================================================================= */}

      {verified && (
        <>
          <div
            style={{
              background: '#ecfdf3',
              border: '1px solid #abefc6',
              padding: '25px',
              borderRadius: '14px',
              marginBottom: '20px',
            }}
          >
            <div style={{ fontSize: '35px' }}>
              ✅
            </div>

            <h2
              style={{
                color: '#067647',
                margin: '8px 0',
              }}
            >
              Access Granted
            </h2>

            <p style={{ color: '#475467' }}>
              Worker identity verified successfully. Clinical
              records are now available for this consultation.
            </p>
          </div>

          {/* ACCESS SUMMARY */}

          {!showRecords && (
            <div
              style={{
                background: '#ffffff',
                padding: '28px',
                borderRadius: '14px',
                boxShadow: '0 4px 18px rgba(0,0,0,0.05)',
              }}
            >
              <h2
                style={{
                  color: '#073b4c',
                  marginTop: 0,
                }}
              >
                {worker.name}
              </h2>

              <p style={{ color: '#667085' }}>
                Health ID: <strong>{worker.healthId}</strong>
              </p>

              <div
                style={{
                  marginTop: '20px',
                  padding: '15px',
                  background: '#eef8f7',
                  borderRadius: '9px',
                  color: '#087f8c',
                }}
              >
                🔐 Consent verified for clinical record access.
              </div>

              <button
                type="button"
                onClick={() => setShowRecords(true)}
                style={{
                  ...primaryButton,
                  marginTop: '22px',
                }}
              >
                View Clinical Records
              </button>
            </div>
          )}

          {/* ============================================================
              CLINICAL RECORDS
          ============================================================= */}

          {showRecords && (
            <div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '18px',
                }}
              >
                <div>
                  <h2
                    style={{
                      margin: 0,
                      color: '#073b4c',
                    }}
                  >
                    Clinical Records
                  </h2>

                  <p style={{ color: '#667085' }}>
                    {worker.name} · {worker.healthId}
                  </p>
                </div>

                <span
                  style={{
                    background: '#e5f6f3',
                    color: '#087f8c',
                    padding: '7px 13px',
                    borderRadius: '20px',
                    fontWeight: '600',
                  }}
                >
                  3 Records
                </span>
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns:
                    'repeat(auto-fit, minmax(280px, 1fr))',
                  gap: '18px',
                }}
              >
                {demoRecords.map((record, index) => (
                  <div
                    key={index}
                    style={{
                      background: '#ffffff',
                      borderRadius: '14px',
                      padding: '22px',
                      boxShadow: '0 4px 18px rgba(0,0,0,0.05)',
                      border: '1px solid #e5e7eb',
                    }}
                  >
                    <div style={{ fontSize: '28px' }}>
                      {record.type === 'Consultation'
                        ? '🩺'
                        : record.type === 'Prescription'
                        ? '💊'
                        : '🧪'}
                    </div>

                    <p
                      style={{
                        color: '#087f8c',
                        fontSize: '13px',
                        fontWeight: '600',
                        marginBottom: '5px',
                      }}
                    >
                      {record.type}
                    </p>

                    <h3
                      style={{
                        margin: '5px 0 12px',
                        color: '#073b4c',
                      }}
                    >
                      {record.title}
                    </h3>

                    <p style={{ color: '#667085' }}>
                      <strong>Diagnosis:</strong>{' '}
                      {record.diagnosis}
                    </p>

                    <p style={{ color: '#667085' }}>
                      <strong>Doctor:</strong>{' '}
                      {record.doctor}
                    </p>

                    <p style={{ color: '#667085' }}>
                      <strong>Date:</strong>{' '}
                      {record.date}
                    </p>

                    <p
                      style={{
                        color: '#667085',
                        marginBottom: 0,
                      }}
                    >
                      <strong>Notes:</strong>{' '}
                      {record.notes}
                    </p>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={resetFlow}
                style={{
                  ...primaryButton,
                  marginTop: '25px',
                }}
              >
                Start New Access Request
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// INFO BOX
// ----------------------------------------------------------------------

function InfoBox({ label, value }) {
  return (
    <div
      style={{
        padding: '15px',
        background: '#f8faf9',
        borderRadius: '9px',
      }}
    >
      <div
        style={{
          fontSize: '13px',
          color: '#667085',
          marginBottom: '5px',
        }}
      >
        {label}
      </div>

      <strong style={{ color: '#073b4c' }}>
        {value}
      </strong>
    </div>
  );
}

// ----------------------------------------------------------------------
// PRIMARY BUTTON
// ----------------------------------------------------------------------

const primaryButton = {
  padding: '12px 22px',
  border: 'none',
  borderRadius: '8px',
  background: '#087f8c',
  color: '#ffffff',
  cursor: 'pointer',
  fontWeight: '600',
};

export default DoctorAccess;