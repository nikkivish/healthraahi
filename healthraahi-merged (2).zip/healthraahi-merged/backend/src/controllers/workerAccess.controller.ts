import { Request, Response, NextFunction } from "express";
import { WorkerProfile } from "../models/WorkerProfile";
import { AppError } from "../middleware/errorHandler";

export const verifyWorkerQrPin = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    if (!req.user) {
      throw new AppError("Authentication required", 401);
    }

    if (req.user.role !== "DOCTOR") {
      throw new AppError("Doctor access required", 403);
    }

    const { healthId, pin } = req.body;

    if (!healthId || !pin) {
      throw new AppError("Health ID and PIN are required", 400);
    }

    const normalizedHealthId = String(healthId).trim().toUpperCase();
    const normalizedPin = String(pin).trim();

    const workerProfile = await WorkerProfile.findOne({
      healthId: normalizedHealthId,
    }).lean();

    if (!workerProfile) {
      throw new AppError("Worker not found", 404);
    }

    const DEMO_HEALTH_PIN = "1234";

    if (normalizedPin !== DEMO_HEALTH_PIN) {
      throw new AppError("Invalid Health PIN", 403);
    }

    res.status(200).json({
      success: true,
      message: "Worker identity verified successfully",
      data: {
        verified: true,
        healthId: workerProfile.healthId,
        workerId: workerProfile.userId,
      },
    });
  } catch (error) {
    next(error);
  }
};